<?php
use PatricPoba\MtnMomo\MtnConfig;

 
$config = new MtnConfig([ 
    // mandatory credentials
    'baseUrl'               => 'https://sandbox.momodeveloper.mtn.com', 
    'currency'              => 'EUR', 
    'targetEnvironment'     => 'sandbox', 

    // collection credentials
    "collectionApiSecret"   => '3463953c31064e6e8ae634cd94f13c8c', 
    "collectionPrimaryKey"  => 'aadb6f286e95415db9024c7a4e2c6025', 
    "collectionUserId"      => 'b4d4019f-8617-4843-a4b8-ed90941747a3'
]);


$collection = new MtnCollection($config); 

$params = [
    "mobileNumber"      => '0546861073', 
    "amount"            => '100', 
    "externalId"        => '774747234',
    "payerMessage"      => 'some note',
    "payeeNote"         => '1212'
];

$transactionId = $collection->requestToPay($params);

$transaction = $collection->getTransaction($transactionId);

$transaction = $collection->getBalance();

$transaction = $collection->accountHolderActive($mobileNumber);